# coding: utf-8
def Saludar_desde_py3():
    print('Hola, esta función vive en el archivo Saludo_py3.py')
    
# Archivo auxiliar del tutorial de Python 3.
# Ir a las herramientas: http://sistemas.fciencias.unam.mx/~rich/Herramientas)
# Curso relacionado con este notebook: [Física Computacional.](http://sistemas.fciencias.unam.mx/~rich/FisComp/)
# Se agradece el apoyo de los proyectos DGAPA-PAPIME:
# + PE 112919 durante el año 2020. *Mantenimiento general, actualización a la última versión de Python*
# + PE 105017 durante el año 2017. *Idea original.*
