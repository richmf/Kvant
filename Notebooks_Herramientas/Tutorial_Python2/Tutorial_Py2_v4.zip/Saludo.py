# -*- coding: utf-8 -*-

def Saludar_desde_py():
    print 'Hola, esta función vive en el archivo Saludo.py'

# Archivo auxiliar del tutorial de Python 2.
# Ir a las herramientas: http://sistemas.fciencias.unam.mx/~rich/Herramientas)
# Curso relacionado con este notebook: [Física Computacional.](http://sistemas.fciencias.unam.mx/~rich/FisComp/)
# Se agradece el apoyo de los proyectos DGAPA-PAPIME:
# + PE 112919 durante el año 2020. *Mantenimiento general, y ultima actualizacion de este tutorial*
# + PE 105017 durante el año 2017. *Idea original.*
